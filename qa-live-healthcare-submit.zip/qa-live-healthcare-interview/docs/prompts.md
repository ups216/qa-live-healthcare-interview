# AI Coding Prompts

## 角色设定
你是一位资深 Full Stack Engineer，擅长 Vue 3、Spring Boot、MySQL 和 Docker。
我将以“技术负责人”的身份给你下达任务，你需要严格按照我的要求输出代码、文档和测试用例。
所有输出需符合企业级交付标准。

## 通用约束
- 所有代码、文档必须通过 AI 生成，我仅负责审核与微调。
- 遵循 Clean Code 原则。
- 每一步完成后等待我确认。

## 任务列表
## 任务 1: 生成 PRD 模板与登录功能 PRD
- 使用 AI 工具：Tencent Workbuddy
- 使用的 Prompt: 

## 1. 问诊用户登录 PRD 生成提示词

**用途**：基于标准 PRD 模板，生成"问诊用户登录"功能的产品需求文档。

**提示词（Prompt）**：

```
我正在参加一个医疗 QA 系统的面试。请根据以下要求，帮我编写一个标准的 PRD（产品需求文档）模板，并基于该模板，为我撰写"问诊用户登录"功能的 PRD 文档。

背景：当前系统前端使用 Vue 3，后端有一个 qa-service-user 服务。

需求：为问诊用户提供用户名密码登录方式。

要求：
1. 先输出 PRD 模板，包含：需求背景、用户故事、功能需求、接口定义、数据表设计、非功能性需求。
2. 再基于模板输出"问诊用户登录"的详细 PRD。
3. 输出格式为 Markdown，文件将存放在 /docs 目录。
4. 如果需求较大，请在 PRD 中给出合理的拆分步骤。
5. 请在最后附上你使用的 AI Coding 提示词（Prompt），以便记录到 docs/prompts.md 中。
```

**设计要点（撰写 PRD 时的关键决策）**：

| 决策点 | 选择 | 理由 |
| --- | --- | --- |
| 密码存储 | BCrypt 加盐哈希 | 医疗场景安全优先，BCrypt 自带盐且抗彩虹表 |
| Token 方案 | JWT 双 Token（Access + Refresh） | 无状态易扩展，Refresh 兼顾安全与体验 |
| 错误提示策略 | "用户名或密码错误"统一提示 | 不区分账号是否存在，防撞库 |
| 防暴力破解 | Redis 失败计数 + 锁定 | 轻量高效，TTL 自动解锁 |
| 登出失效 | Redis Token 黑名单 | 弥补 JWT 无法主动失效的缺陷 |
| 需求拆分 | P0 核心闭环 + P1 安全增强 | 先能用后加固，控制首期复杂度 |

**产出文件**：

- `docs/PRD模板.md` — 标准 PRD 模板
- `docs/问诊用户登录PRD.md` — 问诊用户登录详细 PRD
- `docs/prompts.md` — 本提示词记录

---

## 2. 提示词使用建议

1. **替换背景信息**：将 `Vue 3` / `qa-service-user` 替换为实际技术栈与服务名。
2. **调整需求范围**：如需短信登录、第三方登录，在"需求"段补充对应描述。
3. **迭代 PRD**：在已有 PRD 基础上追加"请基于现有 PRD，新增 XX 功能章节"即可增量更新。
4. **接口联调**：可追加提示"请基于上述接口定义，生成 Vue 3 前端 axios 封装与 Spring Boot Controller 代码"。

## 任务 2：生成 docker-compose.yml
- 使用 AI 工具：Tencent WorkBuddy
- 使用的 Prompt：

我正在参加一个医疗 QA 系统的面试。请根据以下要求，生成一个 docker-compose.yml文件。

需求：

使用 MySQL 8.0 作为数据库。

挂载 phpMyAdmin 作为数据库管理界面。

MySQL 配置要求：

数据库名：healthcare_qa

用户名：qa_user

密码：qa_password

Root 密码：root_password

端口映射：3306:3306

phpMyAdmin 配置要求：

端口映射：8081:80

环境变量：PMA_HOST=mysql

使用 Docker volume 持久化 MySQL 数据。

服务命名规范：

MySQL 服务名：mysql

phpMyAdmin 服务名：phpmyadmin

输出格式：仅输出 docker-compose.yml的完整内容，不要额外解释。

文件将存放在项目根目录（qa-live-healthcare-interview/docker-compose.yml）。

注意：

这是面试项目，配置不需要生产级安全，但要保证本地可运行。

后续我会在 /docs/prompts.md中记录本次使用的 Prompt。
- 生成文件：
  - docker-compose.yml

### 配置修正：MySQL Root 密码更新
- **背景**：初始生成的 `docker-compose.yml` 中 `MYSQL_ROOT_PASSWORD` 设置为占位符 `root_password`，不符合本地安全规范及后续联调需求。
- **操作时机**：在首次执行 `docker compose up -d` 后发现无法通过 `root_password` 登录，随即进行修正。
- **修正内容**：
  - 将 `MYSQL_ROOT_PASSWORD` 由 `root_password` 修改为强密码 `Daphne123`。
  - 由于 Docker Volume 会持久化数据，修改 yml 后需执行以下步骤使密码生效：
    1. 停止并删除容器：`docker compose down`
    2. 删除旧数据卷（强制重新初始化）：`docker volume rm qa-live-healthcare-interview_mysql_data`
    3. 重启服务：`docker compose up -d`
- **验证方式**：
  - 执行 `docker exec -it healthcare_qa_mysql mysql -u root -p`
  - 输入新密码 `Daphne123`，成功进入 MySQL Shell。
- **影响范围**：
  - 后端 `application.properties` 中的 `spring.datasource.password` 需同步配置为 `Daphne123`。

## 任务 3：生成前端 Vue 3 + i18n 项目代码
- 使用 AI 工具：Tencent WorkBuddy
- 目标目录：`web/qa-web`
- 技术栈：Vue 3 + TypeScript + Vite + vue-i18n@9
- 需求背景：
  - 为医疗 QA 系统首页添加中英文切换能力
  - 页面右上角添加语言切换下拉菜单
  - 语言资源文件必须存放在 `web/qa-web/src/locales` 目录
  - 前端通过 `/api/doctors` 调用后端接口获取医生列表
- 详细要求（发给 AI 的完整 Prompt）：
  你是一个资深 Vue 3 开发者。我有一个 Vite + TypeScript 项目，位于 `web/qa-web/` 目录。

请帮我完成以下任务：

1. 安装并配置 vue-i18n@9（Vue 3 兼容版）：
   - 在 `src/locales/` 目录下创建两个语言文件：
     - `zh-CN.json`
     - `en-US.json`
   - 内容示例：
json

// zh-CN.json

{

"home.title": " healthcare 问答系统",

"home.welcome": "欢迎来到 healthcare 问答系统",

"home.description": "这里是医生列表页面",

"doctors.title": "医生列表",

"doctors.name": "姓名",

"doctors.specialty": "专业"

}

// en-US.json
{
  "home.title": "Healthcare Q&A System",
  "home.welcome": "Welcome to Healthcare Q&A System",
  "home.description": "This is the doctor list page",
  "doctors.title": "Doctor List",
  "doctors.name": "Name",
  "doctors.specialty": "Specialty"
}
```
在 src/main.ts中初始化 i18n：

ts
import { createApp } from 'vue'
import App from './App.vue'
import { createI18n } from 'vue-i18n'

const i18n = createI18n({
  legacy: false, // 使用 Composition API
  locale: 'zh-CN', // 默认中文
  fallbackLocale: 'en-US',
  messages: {
    'zh-CN': require('./locales/zh-CN.json'),
    'en-US': require('./locales/en-US.json')
  }
})

const app = createApp(App)
app.use(i18n)
app.mount('#app')
修改 src/App.vue或 src/views/Doctors.vue（如果存在）：

在右上角添加一个语言切换下拉框：

vue
<template>
  <div class="language-switch">
    <select v-model="$i18n.locale">
      <option value="zh-CN">中文</option>
      <option value="en-US">English</option>
    </select>
  </div>

  <h1>{{ $t('home.title') }}</h1>
  <p v-if="doctors.length > 0">
    <strong>{{ $t('doctors.title') }}:</strong>
    <ul>
      <li v-for="doctor in doctors" :key="doctor.id">
        {{ doctor.name }} - {{ doctor.specialty }}
      </li>
    </ul>

  <p v-else>暂无医生数据
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const doctors = ref([])

onMounted(async () => {
  try {
    const res = await axios.get('/api/doctors')
    doctors.value = res.data
  } catch (err) {
    console.error('获取医生失败', err)
  }
})
</script>
确保 vite.config.ts中代理配置正确（解决跨域）：

ts
export default defineConfig({
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080', // 后端地址
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      }
    }
  }
})
输出文件：

src/locales/zh-CN.json

src/locales/en-US.json

src/main.ts（修改后）

src/App.vue或 src/views/Doctors.vue（修改后）

vite.config.ts（修改后）

请确保所有文件都符合 Vue 3 + TypeScript + Vite 规范，并给出清晰的注释。

## 任务 4：生成后端 Spring Boot 项目代码
- 技术栈：Java 17 + Spring Boot 3.x + Spring Data JPA + MySQL
- 项目路径：`qa-service-user`
- 功能：
- 提供 `/api/doctors` 接口，返回医生列表（JSON）
- 使用 MySQL 数据库（已由 docker-compose 启动）
- 数据库名：`healthcare_qa`
- 用户名：`root`
- 密码：`Daphne123`
- 输出文件：
- `src/main/java/com/example/qa/entity/Doctor.java`
- `src/main/java/com/example/qa/repository/DoctorRepository.java`
- `src/main/java/com/example/qa/service/DoctorService.java`
- `src/main/java/com/example/qa/controller/DoctorController.java`
- `src/main/resources/application.properties`
- `pom.xml`
- 放置位置：`C:\Users\lanla\qa-live-healthcare-interview\qa-service-user`

> Prompt 原文：
你是一个资深 Spring Boot 开发者。我有一个 Maven 项目，位于 qa-service-user/目录。

请帮我完成以下任务：

创建一个 Doctor实体类：

java
package com.example.qa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Doctor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String specialty;

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }
}

创建 DoctorRepository接口：

java
package com.example.qa.repository;

import com.example.qa.entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoctorRepository extends JpaRepository<Doctor, Long> {
}

创建 DoctorService类：

java
package com.example.qa.service;

import com.example.qa.entity.Doctor;
import com.example.qa.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }
}

创建 DoctorController类：

java
package com.example.qa.controller;

import com.example.qa.entity.Doctor;
import com.example.qa.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @GetMapping("/doctors")
    public List<Doctor> getDoctors() {
        return doctorService.getAllDoctors();
    }
}

确保 application.properties配置正确：

properties
spring.datasource.url=jdbc:mysql://localhost:3306/healthcare_qa?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=your_password_here  # 替换为你自己的密码
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true

确保 pom.xml中有必要依赖：

xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>mysql</groupId>
        <artifactId>mysql-connector-java</artifactId>
        <scope>runtime</scope>
    </dependency>
</dependencies>

输出文件：

src/main/java/com/example/qa/entity/Doctor.java

src/main/java/com/example/qa/repository/DoctorRepository.java

src/main/java/com/example/qa/service/DoctorService.java

src/main/java/com/example/qa/controller/DoctorController.java

src/main/resources/application.properties（修改后）

pom.xml（确保依赖正确）

请确保所有文件都符合 Spring Boot 3.x + Java 17 规范，并给出清晰的注释。

## 任务 5：前端项目迁移与验证
- 将 WorkBuddy 生成的前端文件复制到 `web/qa-web`
- 执行 `npm install`
- 启动前端 `npm run dev`
- 验证页面是否能加载（即使无数据）
详细启动与排查步骤参见文档末尾《附录：本地开发与前后端联调说明》

## 任务 6：后端项目迁移与启动
- 将 WorkBuddy 生成的后端文件复制到 `qa-service-user`
- 执行 `mvn spring-boot:run`
- 验证 `/api/doctors` 是否可访问
后端启动后，建议参照附录验证接口可用性。

## 任务 7：后端接口验证与数据初始化
- **目标**：验证后端 API 是否可访问，并确认数据库映射关系。
- **操作过程**：
  1. 在浏览器访问 `http://localhost:8080/api/doctors`，确认接口返回空数组 `[]`，表明服务通畅。
  2. 通过 phpMyAdmin 向数据库插入测试数据。
  3. **关键发现**：系统中存在 `doctor`（单数）和 `doctors`（复数）两张表。接口实际返回的是 `doctor` 表的数据。
  4. 排查 `Doctor.java` 实体类，确认未配置 `@Table(name="...")` 注解。
  5. **结论**：Spring Boot JPA 默认命名策略将实体 `Doctor` 映射为表名 `doctor`（单数），因此接口读取的是 `doctor` 表数据。这符合 JPA 默认行为，无需修改代码。
- **验证结果**：
  - 接口 `http://localhost:8080/api/doctors` 成功返回数据库中的真实数据（中文医生信息）。
  - 数据库映射逻辑清晰，数据一致性得到保证。
  - 删除多余的 `doctors`（复数）表。

## 任务 8：前端项目启动与环境配置
- **目标**：启动 Vue 3 前端项目，并验证与后端的初步联通。
- **操作过程**：
  1. 进入 `web/qa-web` 目录，执行 `npm install` 安装依赖（此前已完成）。
  2. 执行 `npm run dev` 启动前端开发服务器，访问 `http://localhost:5173`。
  3. 页面标题显示为“healthcare 问答系统”，右上角语言切换功能正常。
- **遇到的问题**：
  - 页面显示“获取医生列表失败”。
  - 打开浏览器开发者工具（F12），Network 面板显示请求 `http://localhost:5173/api/doctors` 失败。
- **问题分析**：
  - 后端接口 `http://localhost:8080/api/doctors` 单独访问正常，说明后端服务无异常。
  - 前端运行在 `5173` 端口，后端运行在 `8080` 端口，浏览器因**同源策略（CORS）**拦截了跨域请求。
- **下一步计划**：解决前后端联调的跨域问题。

## 任务 9：前后端联调与 CORS 跨域问题修复（Vite 代理方案）
- **目标**：解决前端 `localhost:5173` 无法调用后端 `localhost:8080` 接口的问题，实现数据正常渲染。
- **问题现象**：
  - 前端页面打开后，医生列表区域显示“获取医生失败”。
  - 浏览器 Console 报错：`Access-Control-Allow-Origin` 相关错误。
  - 但直接访问 `http://localhost:8080/api/doctors` 能正常返回 JSON 数据。
- **根因分析**：
  - 浏览器出于安全考虑，实施了**同源策略（Same-Origin Policy）**。
  - 前端（5173端口）与后端（8080端口）存在**端口号差异**，被视为不同源。
  - 浏览器自动拦截了前端发起的跨域 AJAX/Fetch 请求。
- **解决方案选型**：
  - **方案 A（后端修改）**：在 Spring Boot 中增加 `@CrossOrigin` 注解或全局 CORS 过滤器。
  - **方案 B（前端代理）**：利用 Vite 内置的开发服务器代理（Dev Proxy）功能，将 API 请求转发。
  - **决策**：选用 **方案 B**。理由：无需侵入后端业务代码，符合前后端分离架构的开发环境最佳实践，且配置灵活。
- **Prompt 原文（用于 AI 生成配置）**：
  > 请帮我修改 Vite 配置文件（`web/qa-web/vite.config.ts`），添加开发服务器代理（Proxy）配置。
  > 要求：
  > 1. 前端运行在 5173 端口，后端运行在 8080 端口。
  > 2. 将所有以 `/api` 开头的 HTTP 请求代理到 `http://localhost:8080`。
  > 3. 设置 `changeOrigin: true`。
  > 4. 不需要重写路径（rewrite），因为后端接口本身就包含 `/api` 前缀。
- **实施步骤**：
  1. 修改 `web/qa-web/vite.config.ts`，添加 `server.proxy` 配置项。
  2. 重启 Vite 开发服务器（`npm run dev`）。
  3. 刷新浏览器页面，观察 Network 面板。
- **验证结果**：
  - 页面医生列表成功加载数据库中的中文医生数据。
  - Network 面板显示 `/api/doctors` 请求状态码为 **200 OK**。
  - 中英文切换功能正常，不受数据层变更影响。
- **经验总结**：在开发环境中，使用 Vite Proxy 是解决跨域问题的最优解之一，它隐藏了后端真实地址，避免了 CORS 预检请求的复杂性。

## 任务 10：问诊用户登录功能（PRD 驱动开发）
- **需求背景**：为问诊用户提供用户名密码登录方式（需求列表第 3 条）。
- **文档先行**：
  - 已编写 `/docs/PRD模板.md`
  - 已基于模板生成 `/docs/PRD_Login.md`
  - PRD 中包含：用户故事、功能需求、接口定义、数据表设计、非功能性需求
- **AI 开发指导（Prompt 原文）**：
  > 请根据以下 PRD 文档，为医疗 QA 系统设计并实现“问诊用户登录”功能。
  >
  > **PRD 文档位置**：`/docs/PRD_Login.md`
  >
  > **技术要求**：
  > 1. 后端：Spring Boot + Spring Security + JWT（或 Session）
  > 2. 数据库：MySQL，新增 `user` 表（id, username, password_hash, role）
  > 3. 接口：`POST /api/login`
  > 4. 密码加密：BCrypt
  > 5. 前端：Vue 3 登录页面，调用 `/api/login` 接口
  >
  > **拆分步骤（已在 PRD 中定义）**：
  > 1. 数据库表设计与创建
  > 2. 后端用户实体与 Repository
  > 3. 后端登录接口实现
  > 4. 前端登录页面开发
  > 5. 前后端联调
  >
  > **输出要求**：
  > - 后端 Java 代码
  > - 前端 Vue 组件
  > - SQL 建表语句
  > - 更新 `application.properties`
- **执行结果**：
  - AI 已生成完整登录功能代码（见附件/分支）
  - 受限于面试时间，代码已生成但尚未集成到当前运行环境
  - **开发流程完整走通：PRD → AI 代码生成 → 人工审查**
- **结论**：
  - 符合“指导 AI 使用 PRD 完成特性开发”的面试要求
  - 体现了需求驱动开发的工程规范

---

## 任务 11：API 测试文档与测试执行
- **背景**：面试要求"使用 curl 构建对于以上需求中所涉及的所有接口的测试"并"提供 `/docs/API_TEST.md`"。
- **文档编写**：
  - 已编写 `/docs/API_TEST.md`（见上方完整内容）
  - 覆盖接口：医生列表 GET `/api/doctors`、前端页面加载、语言切换
  - 包含 curl 测试命令、预期结果、异常场景、端到端联调流程
- **AI 测试执行 Prompt**：
  > 请根据 `/docs/API_TEST.md` 中定义的测试用例，逐项执行接口测试。
  > 要求：
  > 1. 使用 curl 执行每个接口的测试命令。
  > 2. 记录实际响应（状态码、响应体、响应头）。
  > 3. 对比预期结果，标注通过/未通过。
  > 4. 生成测试报告，保存为 `/docs/测试报告.md`。
  > 5. 报告格式：Markdown，包含测试时间、环境信息、各接口详细结果、汇总结论。
- **执行方式**：
  - 在本地环境启动完整服务链路后，逐项执行 curl 命令
  - 将实际结果与 API_TEST.md 中的预期结果对比
- **输出文件**：
  - `/docs/测试报告.md`

## 附录：本地开发与前后端联调说明

本文档用于指导本地环境快速启动与问题排查，确保面试评审人员可复现运行效果。

### 1. 环境依赖
- Docker Desktop（含 WSL 2）
- Java 17
- Maven 3.9+
- Node.js 18+
- MySQL 8.0（由 Docker Compose 托管）

### 2. 启动顺序（重要）

#### 2.1 启动基础设施（MySQL）
bash

docker compose up -d

验证：
- `docker ps` 可见 `mysql` 与 `phpmyadmin` 容器
- 访问 http://localhost:8081（phpMyAdmin）

#### 2.2 启动后端服务
bash

cd qa-service-user

mvn spring-boot:run
验证：
- 控制台显示 `Started QaServiceUserApplication`
- 访问 http://localhost:8080/api/doctors 返回 JSON 数据

#### 2.3 启动前端服务
bash

cd web/qa-web

npm install

npm run dev
验证：
- 访问 http://localhost:5173
- 页面显示医生列表
- 右上角语言切换功能正常

### 3. 常见问题排查

| 现象 | 排查点 |
|----|----|
| 前端显示“获取医生失败” | 检查 `vite.config.ts` 中代理是否指向 `http://localhost:8080` |
| 后端启动失败（数据库连接异常） | 检查 `application.properties` 中 `spring.datasource.password` 是否为 `Daphne123` |
| MySQL 无法登录 | 确认 Docker Volume 已重建，密码已更新 |
| 端口冲突 | 确认 8080 / 5173 / 8081 未被其他进程占用 |

### 4. 联调验证清单
- [ ] 后端接口 `http://localhost:8080/api/doctors` 可访问
- [ ] 前端页面 `http://localhost:5173` 可加载
- [ ] 医生列表数据正确显示
- [ ] 中英文切换功能正常
- [ ] 浏览器 Network 面板无 CORS 报错

---