# 问诊用户登录 产品需求文档（PRD）

> 基于《PRD 标准模板》撰写。技术栈：前端 Vue 3，后端服务 `qa-service-user`。

---

## 0. 文档信息

| 字段 | 内容 |
| --- | --- |
| 文档名称 | 问诊用户登录 产品需求文档 |
| 文档版本 | v1.0 |
| 当前状态 | 评审中 |
| 作者 | {{作者}} |
| 创建日期 | 2026-07-03 |
| 最后更新 | 2026-07-03 |
| 评审人 | 产品 / 前端 / 后端 / 测试 / 安全 |

### 版本记录

| 版本 | 日期 | 修改人 | 修改内容 |
| --- | --- | --- | --- |
| v1.0 | 2026-07-03 | {{作者}} | 初稿创建 |

---

## 1. 需求背景

### 1.1 业务现状

医疗 QA 系统面向问诊用户提供在线问诊、健康咨询、报告查询等服务。当前系统已完成问诊会话、知识问答等核心能力，但**尚未建立问诊用户的统一登录与身份识别机制**，导致：

- 无法区分不同问诊用户，问诊记录、健康档案无法与个人绑定；
- 敏感医疗数据缺少访问控制，存在越权访问风险；
- 后续的问诊历史、收藏、个人中心等功能缺乏身份基础。

前端基于 **Vue 3** 构建，后端鉴权与用户管理由 **`qa-service-user`** 服务负责。

### 1.2 用户痛点

- 痛点 1：用户每次进入系统无法留存问诊历史，体验割裂；
- 痛点 2：系统无法识别用户身份，医疗数据无法安全归属到个人；
- 痛点 3：缺少登录态，后续个人中心、消息通知等功能无法落地。

### 1.3 需求目标与价值

| 维度 | 目标 | 衡量指标 |
| --- | --- | --- |
| 业务目标 | 建立问诊用户身份体系，打通问诊记录与个人档案 | 登录用户问诊历史留存率 ≥ 95% |
| 用户价值 | 用户一次登录即可安全访问个人问诊数据 | 登录耗时 P99 ≤ 1.5s |
| 技术目标 | 统一鉴权，Token 无状态下发，支持后续扩展 | 登录接口可用性 ≥ 99.9% |

### 1.4 名词解释

| 术语 | 含义 |
| --- | --- |
| 问诊用户 | 使用医疗 QA 系统进行在线问诊/健康咨询的 C 端用户 |
| qa-service-user | 负责用户注册、登录、鉴权的后端微服务 |
| Access Token | 登录成功后下发的访问令牌，用于后续接口鉴权 |
| Refresh Token | 用于在 Access Token 过期后换取新令牌的刷新令牌 |

---

## 2. 用户故事

### 2.1 角色定义

| 角色 | 说明 |
| --- | --- |
| 问诊用户 | 系统的 C 端使用者，通过账号密码登录后使用问诊、咨询等服务 |
| 未注册访客 | 尚未拥有账号的访客，可从登录页跳转至注册 |

### 2.2 用户故事列表

| 编号 | 角色 | 故事 | 优先级 |
| --- | --- | --- | --- |
| US-01 | 问诊用户 | 作为问诊用户，我希望通过用户名和密码登录，以便安全访问我的个人问诊数据。 | Must |
| US-02 | 问诊用户 | 作为问诊用户，我希望登录时能看到清晰的错误提示（如密码错误、账号不存在），以便快速修正。 | Must |
| US-03 | 问诊用户 | 作为问诊用户，我希望登录成功后保持登录状态，以便在 Token 有效期内无需重复登录。 | Must |
| US-04 | 问诊用户 | 作为问诊用户，我希望连续输错密码时账号被临时锁定，以便保护我的账号安全。 | Should |
| US-05 | 访客 | 作为未注册访客，我希望从登录页能快速跳转到注册页，以便完成注册。 | Should |
| US-06 | 问诊用户 | 作为问诊用户，我希望可以退出登录，以便在公用设备上保护隐私。 | Must |

---

## 3. 功能需求

### 3.1 功能清单

| 编号 | 功能名称 | 对应故事 | 优先级 | 说明 |
| --- | --- | --- | --- | --- |
| FR-01 | 登录页面展示 | US-01 | Must | Vue 3 登录页，含用户名/密码输入、登录按钮 |
| FR-02 | 表单校验 | US-02 | Must | 前端实时校验 + 后端二次校验 |
| FR-03 | 登录认证 | US-01 | Must | 调用 qa-service-user 校验并下发 Token |
| FR-04 | 登录态维持 | US-03 | Must | Access Token 存储 + 请求自动携带 |
| FR-05 | 登出 | US-06 | Must | 清除本地 Token，通知后端失效 |
| FR-06 | 错误提示 | US-02 | Must | 区分账号不存在、密码错误、被锁定等场景 |
| FR-07 | 登录失败锁定 | US-04 | Should | 连续失败 N 次临时锁定账号 |

### 3.2 功能详细说明

#### FR-01 登录页面展示

- **触发条件**：用户访问需登录页面且未登录，或主动点击"登录"入口
- **前置条件**：无
- **页面元素**：
  - 系统名称 / Logo
  - 用户名输入框（placeholder：请输入用户名）
  - 密码输入框（placeholder：请输入密码，带显示/隐藏切换）
  - "登录"主按钮
  - "忘记密码？"次级链接
  - "没有账号？立即注册"跳转链接
- **输出**：渲染 Vue 3 登录页 `views/login/LoginView.vue`

#### FR-02 表单校验

- **前端实时校验（提交前）**：

| 字段 | 校验规则 |
| --- | --- |
| 用户名 | 非空；长度 4-20；仅允许字母、数字、下划线 |
| 密码 | 非空；长度 8-20；至少包含字母与数字 |

- **后端二次校验**：对所有字段重复校验，防御绕过前端校验的请求
- **验收标准**：
  - [ ] 输入不符合规则时，输入框下方实时红字提示
  - [ ] 校验不通过时"登录"按钮置灰禁用
  - [ ] 后端对非法入参返回 `400` 并给出明确 message

#### FR-03 登录认证（核心）

- **触发条件**：表单校验通过，用户点击"登录"
- **前置条件**：用户名已注册且账号状态正常
- **处理逻辑**：
  1. 前端将用户名 + 密码通过 HTTPS 提交至 `qa-service-user` 登录接口；
  2. 后端按用户名查询 `t_user` 表，校验账号是否存在、是否被锁定；
  3. 后端对用户输入密码做加盐哈希后与库中密文比对（使用 **BCrypt**，cost = 10）；
  4. 校验通过，生成 Access Token（JWT，有效期 2h）与 Refresh Token（有效期 7d）；
  5. 记录登录成功日志（用户ID、IP、UA、时间）；
  6. 返回 Token 与基础用户信息。
- **输出**：
  - 成功：前端保存 Token，跳转至问诊首页；
  - 失败：按场景返回错误码与提示。
- **异常处理**：

| 异常场景 | 处理方式 |
| --- | --- |
| 账号不存在 | 返回 `40001`，提示"用户名或密码错误"（不明确告知账号是否存在，防撞库） |
| 密码错误 | 返回 `40001`，提示"用户名或密码错误"；失败计数 +1 |
| 账号被锁定 | 返回 `40003`，提示"账号已锁定，请 X 分钟后再试" |
| 账号被禁用 | 返回 `40004`，提示"账号已被禁用，请联系客服" |

- **验收标准**：
  - [ ] 正确用户名密码登录成功，返回有效 Token
  - [ ] 错误密码登录失败，提示一致
  - [ ] 密码在传输与存储中均为密文，全程不明文

#### FR-04 登录态维持

- **Token 存储**：
  - Access Token 存于内存（Pinia store）+ `sessionStorage`（刷新页面恢复）；
  - Refresh Token 存于 `httpOnly + Secure + SameSite=Strict` Cookie，防 XSS 读取。
- **请求携带**：axios 请求拦截器自动在 Header 注入 `Authorization: Bearer <accessToken>`。
- **自动续期**：Access Token 过期（401）时，使用 Refresh Token 静默换取新 Token 并重放原请求；Refresh Token 也失效则跳转登录页。
- **验收标准**：
  - [ ] 登录后刷新页面，登录态保持
  - [ ] Token 过期能自动续期，用户无感知
  - [ ] 续期失败时正确跳转登录页

#### FR-05 登出

- **处理逻辑**：
  1. 前端调用登出接口，后端将当前 Token 加入黑名单（Redis，TTL = 剩余有效期）；
  2. 前端清除本地 Token 与用户信息；
  3. 跳转登录页。
- **验收标准**：
  - [ ] 登出后原 Token 立即失效，再次使用返回 401
  - [ ] 本地无残留登录态

#### FR-06 错误提示

- 登录失败时在登录按钮上方以红色文字提示，提示文案 3 秒后自动消失；
- 网络异常提示"网络异常，请稍后重试"。

#### FR-07 登录失败锁定（Should）

- **规则**：同一账号连续登录失败 **5 次**，锁定 **15 分钟**，期间登录直接拒绝；
- 锁定计数与状态存于 Redis（key: `login:fail:{username}`）；
- 锁定到期自动解锁，失败计数清零；
- 登录成功后清空失败计数。

---

## 4. 接口定义

### 4.1 接口清单

| 编号 | 接口名称 | 方法 | 路径 | 鉴权 | 说明 |
| --- | --- | --- | --- | --- | --- |
| API-01 | 用户登录 | POST | `/api/user/login` | 否 | 用户名密码登录，下发 Token |
| API-02 | 刷新令牌 | POST | `/api/user/refresh` | 否（凭 Refresh Token） | 换取新 Access Token |
| API-03 | 用户登出 | POST | `/api/user/logout` | 是 | 使当前 Token 失效 |
| API-04 | 获取当前用户信息 | GET | `/api/user/me` | 是 | 返回登录用户基础信息 |

### 4.2 接口详细定义

#### API-01 用户登录

- **方法**：`POST`
- **路径**：`/api/user/login`
- **鉴权**：否
- **说明**：校验用户名密码，成功后下发 Access Token 与 Refresh Token

**请求参数**

| 字段 | 类型 | 必填 | 说明 | 示例 |
| --- | --- | --- | --- | --- |
| `username` | string | 是 | 用户名，4-20 位字母数字下划线 | `zhang_san` |
| `password` | string | 是 | 用户输入的明文密码（HTTPS 传输），8-20 位含字母数字 | `Pass1234` |

请求示例：
```json
{
  "username": "zhang_san",
  "password": "Pass1234"
}
```

**响应参数**

| 字段 | 类型 | 说明 | 示例 |
| --- | --- | --- | --- |
| `code` | int | 业务状态码，0 表示成功 | `0` |
| `message` | string | 提示信息 | `success` |
| `data.accessToken` | string | 访问令牌（JWT，2h） | `eyJhbGciOi...` |
| `data.refreshToken` | string | 刷新令牌（7d） | `d8f3a9c1...` |
| `data.tokenType` | string | 令牌类型 | `Bearer` |
| `data.expiresIn` | int | Access Token 有效期（秒） | `7200` |
| `data.userInfo.id` | long | 用户 ID | `10086` |
| `data.userInfo.username` | string | 用户名 | `zhang_san` |
| `data.userInfo.nickname` | string | 昵称 | `张三` |
| `data.userInfo.avatar` | string | 头像 URL | `https://...` |

成功响应示例：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
    "refreshToken": "d8f3a9c1b2e7...",
    "tokenType": "Bearer",
    "expiresIn": 7200,
    "userInfo": {
      "id": 10086,
      "username": "zhang_san",
      "nickname": "张三",
      "avatar": "https://cdn.example.com/avatar/10086.png"
    }
  }
}
```

**错误码**

| code | message | 说明 |
| --- | --- | --- |
| `40001` | 用户名或密码错误 | 账号不存在或密码错误（合并提示防撞库） |
| `40002` | 参数校验失败 | 用户名/密码格式不合法 |
| `40003` | 账号已锁定，请稍后再试 | 连续失败超限被锁定 |
| `40004` | 账号已被禁用，请联系客服 | 账号被管理员禁用 |
| `50000` | 系统繁忙，请稍后重试 | 服务内部异常 |

#### API-02 刷新令牌

- **方法**：`POST`
- **路径**：`/api/user/refresh`
- **鉴权**：否（请求体携带 Refresh Token）
- **说明**：用 Refresh Token 换取新的 Access Token

**请求参数**

| 字段 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| `refreshToken` | string | 是 | 登录时下发的刷新令牌 |

成功响应 `data`：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
    "expiresIn": 7200
  }
}
```

**错误码**

| code | message | 说明 |
| --- | --- | --- |
| `40005` | 刷新令牌无效或已过期 | 需重新登录 |

#### API-03 用户登出

- **方法**：`POST`
- **路径**：`/api/user/logout`
- **鉴权**：是（Header 携带 Access Token）
- **说明**：将当前 Access Token 加入黑名单

成功响应：
```json
{ "code": 0, "message": "success", "data": null }
```

#### API-04 获取当前用户信息

- **方法**：`GET`
- **路径**：`/api/user/me`
- **鉴权**：是
- **说明**：根据 Token 解析返回当前登录用户信息，用于刷新页面后恢复登录态

成功响应 `data`：
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": 10086,
    "username": "zhang_san",
    "nickname": "张三",
    "avatar": "https://cdn.example.com/avatar/10086.png"
  }
}
```

---

## 5. 数据表设计

### 5.1 表结构

表名：`t_user`（问诊用户表）

| 字段 | 类型 | 允许空 | 默认 | 说明 |
| --- | --- | --- | --- | --- |
| `id` | bigint | 否 | — | 主键，自增 |
| `username` | varchar(32) | 否 | — | 用户名，唯一 |
| `password_hash` | varchar(100) | 否 | — | BCrypt 加盐哈希后的密码密文，**不明文存储** |
| `salt` | varchar(64) | 否 | — | 密码盐值（BCrypt 内置盐，此字段保留扩展） |
| `nickname` | varchar(32) | 是 | NULL | 昵称 |
| `avatar` | varchar(255) | 是 | NULL | 头像 URL |
| `status` | tinyint | 否 | 1 | 账号状态：1=正常，2=禁用 |
| `last_login_at` | datetime | 是 | NULL | 最后登录时间 |
| `last_login_ip` | varchar(45) | 是 | NULL | 最后登录 IP |
| `created_at` | datetime | 否 | CURRENT_TIMESTAMP | 创建时间 |
| `updated_at` | datetime | 否 | CURRENT_TIMESTAMP | 更新时间（ON UPDATE） |

DDL：
```sql
CREATE TABLE `t_user` (
  `id`            BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
  `username`      VARCHAR(32)  NOT NULL COMMENT '用户名',
  `password_hash` VARCHAR(100) NOT NULL COMMENT 'BCrypt 密码密文',
  `salt`          VARCHAR(64)  NOT NULL DEFAULT '' COMMENT '密码盐值（扩展用）',
  `nickname`      VARCHAR(32)  DEFAULT NULL COMMENT '昵称',
  `avatar`        VARCHAR(255) DEFAULT NULL COMMENT '头像URL',
  `status`        TINYINT      NOT NULL DEFAULT 1 COMMENT '账号状态：1正常 2禁用',
  `last_login_at` DATETIME     DEFAULT NULL COMMENT '最后登录时间',
  `last_login_ip` VARCHAR(45)  DEFAULT NULL COMMENT '最后登录IP',
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='问诊用户表';
```

### 5.2 索引设计

| 索引名 | 类型 | 字段 | 用途 |
| --- | --- | --- | --- |
| `PRIMARY` | 主键 | `id` | 主键查询 |
| `uk_username` | 唯一索引 | `username` | 登录按用户名查询 + 保证用户名唯一 |

### 5.3 缓存设计（Redis）

| Key | 类型 | TTL | 用途 |
| --- | --- | --- | --- |
| `login:fail:{username}` | string（计数） | 15min | 登录失败次数累计，达 5 次锁定 |
| `login:lock:{username}` | string | 15min | 账号锁定标记，存在即拒绝登录 |
| `token:blacklist:{jti}` | string | = Token 剩余有效期 | 登出后 Token 黑名单 |

### 5.4 数据安全

- 密码使用 **BCrypt** 加盐哈希存储，**严禁明文/可逆加密**；
- 密码传输全程 HTTPS，禁止明文 HTTP；
- 登录日志含 IP、UA，用于安全审计；
- 用户真实姓名、身份证等医疗敏感信息不在本表，按需建独立脱敏表。

---

## 6. 非功能性需求

### 6.1 性能需求

| 指标 | 目标值 |
| --- | --- |
| 登录接口 P99 响应时间 | ≤ 500ms（BCrypt 校验为主要耗时） |
| 登录接口 QPS | ≥ 500 |
| 登录页首屏加载 | ≤ 1.5s |

### 6.2 安全需求

- 密码 BCrypt 加盐哈希，cost = 10；
- Access Token 采用 JWT，签名密钥定期轮换；
- Refresh Token 存 httpOnly Cookie，防 XSS；
- 登录接口限流：单 IP 10 次/分钟，单账号 5 次/分钟；
- 错误提示不区分"账号不存在"与"密码错误"，防撞库；
- 符合《个人信息保护法》《数据安全法》及医疗数据合规要求；
- 所有登录行为留审计日志。

### 6.3 可用性与兼容性

- 可用性目标：99.9%；
- 浏览器兼容：Chrome / Edge / Safari 最新两个大版本；
- 端兼容：PC Web + 移动端 H5 自适应。

### 6.4 可观测性

- 登录成功/失败埋点上报，含耗时与失败原因；
- 接口异常接入监控告警（连续失败率 > 阈值告警）；
- 关键链路接入分布式链路追踪（TraceId 贯穿前后端）。

---

## 7. 需求拆分与里程碑

本需求整体不大，但为保证快速上线与安全稳妥，按价值与依赖拆分为两期：

| 阶段 | 范围 | 对应功能 | 交付物 | 预计周期 |
| --- | --- | --- | --- | --- |
| P0（MVP） | 核心登录闭环：页面、校验、登录、Token、登出、错误提示 | FR-01~FR-06, API-01/03/04 | 可用的用户名密码登录 | 1 周 |
| P1（增强） | 安全增强：失败锁定、自动续期、审计日志完善 | FR-07, API-02 | 账号锁定 + 无感续期 | 3 天 |

**拆分依据**：P0 解决"能用"，先打通登录闭环让用户可用；P1 解决"好用 + 安全"，锁定与续期可在 MVP 稳定后补齐，避免一次引入过多复杂度。

---

## 8. 风险与依赖

| 风险/依赖 | 类型 | 影响 | 应对措施 |
| --- | --- | --- | --- |
| BCrypt 校验耗时较高 | 风险 | 高并发下 CPU 压力 | cost 取 10 平衡安全与性能；必要时异步预热 |
| JWT 无法主动失效 | 依赖 | 登出后 Token 仍可用 | Redis Token 黑名单机制兜底 |
| Redis 不可用 | 依赖 | 锁定/黑名单失效 | Redis 降级时登录放行并告警，保证可用性优先 |
| 撞库攻击 | 风险 | 账号被暴力破解 | 限流 + 失败锁定 + 统一错误提示 |
| 合规审计 | 依赖 | 医疗数据需可追溯 | 登录日志全量留存，满足审计要求 |

---

## 9. 附录

- 前端工程：Vue 3 + Vite + Pinia + Vue Router + axios
- 后端服务：`qa-service-user`（Spring Boot）
- 关联文档：
  - 《PRD 标准模板》`docs/PRD模板.md`
  - 《AI Coding 提示词》`docs/prompts.md`
