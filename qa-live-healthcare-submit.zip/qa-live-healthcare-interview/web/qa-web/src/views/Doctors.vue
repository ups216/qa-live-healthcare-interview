<script setup lang="ts">
import { ref, onMounted } from 'vue'
import axios from 'axios'
import { useI18n } from 'vue-i18n'

// 医生数据类型
interface Doctor {
  id: number
  name: string
  specialty: string
}

const { t } = useI18n()

// 医生列表（响应式）
const doctors = ref<Doctor[]>([])
// 加载状态
const loading = ref(false)
// 错误信息
const error = ref('')

onMounted(async () => {
  loading.value = true
  try {
    // 通过 Vite 代理转发到后端：/api/doctors -> http://localhost:8080/doctors
    const res = await axios.get<Doctor[]>('/api/doctors')
    doctors.value = res.data
  } catch (err) {
    console.error(t('doctors.loadError'), err)
    error.value = t('doctors.loadError')
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <section class="doctors">
    <h2>{{ t('doctors.title') }}</h2>

    <!-- 加载中 -->
    <p v-if="loading" class="muted">Loading...</p>

    <!-- 错误提示 -->
    <p v-else-if="error" class="error">{{ error }}</p>

    <!-- 医生列表 -->
    <ul v-else-if="doctors.length > 0" class="doctor-list">
      <li v-for="doctor in doctors" :key="doctor.id" class="doctor-item">
        <span class="name">{{ t('doctors.name') }}: {{ doctor.name }}</span>
        <span class="specialty">{{ t('doctors.specialty') }}: {{ doctor.specialty }}</span>
      </li>
    </ul>

    <!-- 无数据 -->
    <p v-else class="muted">{{ t('doctors.empty') }}</p>
  </section>
</template>

<style scoped>
.doctors h2 {
  font-size: 18px;
  color: #1a1a1a;
  margin: 0 0 12px;
}

.doctor-list {
  list-style: none;
  padding: 0;
  margin: 0;
}

.doctor-item {
  display: flex;
  gap: 24px;
  padding: 10px 12px;
  border: 1px solid #eee;
  border-radius: 6px;
  margin-bottom: 8px;
  background: #fafafa;
}

.doctor-item .name {
  font-weight: 600;
}

.muted {
  color: #999;
}

.error {
  color: #d4380d;
}
</style>
