import { createApp } from 'vue'
import App from './App.vue'
import { createI18n } from 'vue-i18n'

// 以 ESM 方式导入语言包（Vite 不支持 require()）
import zhCN from './locales/zh-CN.json'
import enUS from './locales/en-US.json'

// 创建 i18n 实例
const i18n = createI18n({
  legacy: false, // 使用 Composition API 模式
  locale: 'zh-CN', // 默认语言：中文
  fallbackLocale: 'en-US', // 回退语言：英文
  messages: {
    'zh-CN': zhCN,
    'en-US': enUS
  }
})

const app = createApp(App)
app.use(i18n)
app.mount('#app')
