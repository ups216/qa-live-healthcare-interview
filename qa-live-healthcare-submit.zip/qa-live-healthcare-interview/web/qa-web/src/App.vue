<script setup lang="ts">
import { useI18n } from 'vue-i18n'
import Doctors from './views/Doctors.vue'

// useI18n() 在 legacy: false 下返回响应式的 locale
// 直接绑定 locale.value 即可实现语言切换
const { locale, t } = useI18n()

// 切换语言
function changeLocale(value: string) {
  locale.value = value
}
</script>

<template>
  <div class="app">
    <!-- 右上角语言切换下拉框 -->
    <div class="language-switch">
      <select
        :value="locale"
        @change="changeLocale(($event.target as HTMLSelectElement).value)"
      >
        <option value="zh-CN">中文</option>
        <option value="en-US">English</option>
      </select>
    </div>

    <!-- 标题区 -->
    <header class="header">
      <h1>{{ t('home.title') }}</h1>
      <p class="welcome">{{ t('home.welcome') }}</p>
      <p class="description">{{ t('home.description') }}</p>
    </header>

    <!-- 医生列表 -->
    <main class="main">
      <Doctors />
    </main>
  </div>
</template>

<style scoped>
.app {
  max-width: 800px;
  margin: 0 auto;
  padding: 24px;
  font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
}

.language-switch {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 16px;
}

.language-switch select {
  padding: 6px 12px;
  border: 1px solid #d0d0d0;
  border-radius: 6px;
  font-size: 14px;
  cursor: pointer;
  background: #fff;
}

.language-switch select:focus {
  outline: 2px solid #1677ff;
  border-color: #1677ff;
}

.header h1 {
  font-size: 24px;
  color: #1a1a1a;
  margin: 0 0 8px;
}

.welcome {
  color: #555;
  margin: 0 0 4px;
}

.description {
  color: #888;
  margin: 0 0 24px;
  font-size: 14px;
}
</style>
