import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    port: 5173, // 保持 5173 不变
    proxy: {
      // 把所有以 /api 开头的请求，转发给后端 8080
      '/api': {
        target: 'http://localhost:8080', // 后端地址
        changeOrigin: true,              // 开启跨域代理
        // rewrite: (path) => path.replace(/^\/api/, '') // 如果后端接口没 /api 前缀才需要，你后端有 /api，所以注释掉或删掉这行
      }
    }
  }
})