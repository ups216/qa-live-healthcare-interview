package com.example.qa.controller;

import com.example.qa.entity.Doctor;
import com.example.qa.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 医生控制器
 * <p>
 * 提供医生相关的 RESTful API 接口。
 * </p>
 *
 * @RestController  — 结合 @Controller 和 @ResponseBody，返回 JSON 而非视图
 * @RequestMapping  — 定义该控制器的基础路径前缀
 */
@RestController
@RequestMapping("/api")
public class DoctorController {

    /** 注入医生业务层 */
    @Autowired
    private DoctorService doctorService;

    /**
     * 获取所有医生列表
     * <p>
     * 请求方式：GET
     * 请求路径：/api/doctors
     * 返回格式：JSON 数组
     * </p>
     *
     * @return 医生列表
     */
    @GetMapping("/doctors")
    public List<Doctor> getDoctors() {
        return doctorService.getAllDoctors();
    }
}
