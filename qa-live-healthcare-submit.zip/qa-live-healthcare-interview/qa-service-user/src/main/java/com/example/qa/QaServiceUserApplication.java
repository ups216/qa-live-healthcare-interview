package com.example.qa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Spring Boot 主启动类
 * <p>
 * 这是整个应用的入口点。@SpringBootApplication 是一个组合注解，包含：
 *   - @SpringBootConfiguration：标记为配置类
 *   - @EnableAutoConfiguration：启用 Spring Boot 自动配置
 *   - @ComponentScan：自动扫描当前包及子包下的组件（@Controller、@Service、@Repository 等）
 * </p>
 *
 * 注意：此类应放在最外层包中，以确保组件扫描能覆盖所有子包。
 */
@SpringBootApplication
public class QaServiceUserApplication {

    public static void main(String[] args) {
        SpringApplication.run(QaServiceUserApplication.class, args);
    }
}
