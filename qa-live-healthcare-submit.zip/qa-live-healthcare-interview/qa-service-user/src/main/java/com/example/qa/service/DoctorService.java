package com.example.qa.service;

import com.example.qa.entity.Doctor;
import com.example.qa.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 医生业务逻辑层
 * <p>
 * 负责处理与医生相关的业务逻辑，作为 Controller 与 Repository 之间的中间层。
 * @Service 注解将其注册为 Spring Bean，可被注入到其他组件中。
 * </p>
 */
@Service
public class DoctorService {

    /** 通过构造器注入（推荐）或字段注入方式注入 Repository */
    @Autowired
    private DoctorRepository doctorRepository;

    /**
     * 查询所有医生信息
     *
     * @return 医生列表
     */
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }
}
