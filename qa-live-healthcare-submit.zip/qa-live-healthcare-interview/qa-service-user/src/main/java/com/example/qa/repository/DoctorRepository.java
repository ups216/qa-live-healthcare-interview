package com.example.qa.repository;

import com.example.qa.entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 医生数据访问层接口
 * <p>
 * 继承 JpaRepository 即可获得丰富的 CRUD 操作方法，无需手写 SQL。
 * Spring Data JPA 会在运行时自动生成实现类（动态代理）。
 * </p>
 *
 * 泛型参数说明：
 *   Doctor — 实体类型
 *   Long   — 主键类型
 */
@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
    // JpaRepository 已内置 findAll()、save()、findById()、deleteById() 等方法
    // 如需自定义查询，可在此处添加方法，例如：
    // List<Doctor> findBySpecialty(String specialty);
}
