package com.example.qa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

/**
 * 医生实体类
 * <p>
 * 映射数据库中的 doctor 表，包含医生的基本信息。
 * 使用 JPA（Jakarta Persistence API）注解进行 ORM 映射。
 * </p>
 *
 * @Entity        — 声明这是一个 JPA 实体，对应数据库中的一张表
 * @Id            — 标记主键字段
 * @GeneratedValue — 主键生成策略，IDENTITY 表示由数据库自增
 */
@Entity
public class Doctor {

    /** 主键 ID，由数据库自增生成 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** 医生姓名 */
    private String name;

    /** 专业领域（如：内科、外科、儿科等） */
    private String specialty;

    // ==================== Getters & Setters ====================

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
}
